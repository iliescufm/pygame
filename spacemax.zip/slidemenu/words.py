#!/usr/bin/env python
# -*- coding: latin-1 -*-
global rouge,vert,bleu,noir,jaune,orange,blanc,words

words=[
       ["Jouer","Play"], #0
       ["Meilleurs scores","High Scores"], #1
       ["Vitesse","Speed"], #2
       ["Remerciements","Special thanks"], #3
       ["Langue","Langage"], #4
       ["Quitter","Exit"], #5
       ["Niveau : ","Level : "], #6
       ["Vie : ","Life : "], #7
       ["Bombe : ","Bomb : "], #8
       ["Puissance : ","Power : "], #9
       ["Score : ","Score : "], #10
       ["Bouclier : ","Shield : "], #11
       ["<-- Droite et Gauche -->","<-- Left and Right -->"], #12
       ["SpaceMax, c'est plus fort que toi !","SpaceMax, it's stronger than you !"],#13
       ["Entrer votre nom : ","Enter your name : "],#14
       ["Remerciements � ", "Special Thanks to"],#15
       ["",""],
       ["Guido van Rossum "," Guido van Rossum"], #17
       ["pour l'invention de ce langage formidable","for the invention of this awesome langage"], #18
       ["",""],
       ["L'�quipe de Pygame","Pygame's team"],#20
       ["pour la splendide librairie et tout le reste...","for the splendid librairie and many more things..."],#21
       ["Visiter http://www.pygame.org","See here http://www.pygame.org"],#22
       ["",""],
       ["http://www.universal-soundbank.com/","http://www.universal-soundbank.com/"],#24
       ["pour les sons"," for the sounds"], #25
       ["",""],
       ["Josmiley          ","Josmiley          "], #27
       ["pour son joli menu slidemenu","for the pretty librairy slidemenu"],#28
       ["Visiter http://joel-murielle.perso.sfr.fr/","See here  http://joel-murielle.perso.sfr.fr/"],#29
       ["",""],
       ["Maya et Gabriel","Maya and Gabriel"],#31
       ["pour leurs jolis dessins et leurs bonnes id�es","for her pretty drawings and for their good ideas"], #32
       ["",""],
       ["Tous les gars qui m'ont fait un retour","All guys for the precious feedbacks"],#34
       ["",""],
       ["",""],
       ["",""],
       ["",""],
       ["",""],
       ["",""],
       ["SpaceMax","SpaceMax"],#41
       ["https://sites.google.com/site/gamemaxpy/","https://sites.google.com/site/gamemaxpy/"], #42
       ["�Copyleft 2012","�Copyleft 2012"]
       ]
