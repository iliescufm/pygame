from django.apps import AppConfig


class TrosnothConfig(AppConfig):
    name = 'trosnoth.djangoapp'
    label = 'trosnoth'
    verbose_name = 'Trosnoth Server'
