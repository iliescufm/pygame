shadowDefault = (0, 0, 0)
shadowAgainstGrey = (0, 0, 0)
